// 全局变量
let materials = JSON.parse(localStorage.getItem('materials')) || [];
let quotationItems = [];
let currentEditingMaterial = null;
let systemSettings = {
    defaultCompanyName: '',
    minDiscountRate: 0.8
};
let originalPrices = []; // 存储原始价格

// DOM 元素
const quotationTab = document.getElementById('quotationTab');
const settingsTab = document.getElementById('settingsTab');
const quotationPage = document.getElementById('quotationPage');
const settingsPage = document.getElementById('settingsPage');
const addRowBtn = document.getElementById('addRowBtn');
const calculateBtn = document.getElementById('calculateBtn');
const discountBtn = document.getElementById('applyDiscountBtn');
const restorePriceBtn = document.getElementById('restoreOriginalPricesBtn');
const exportBtn = document.getElementById('exportBtn');
const clearBtn = document.getElementById('clearBtn');
const addMaterialBtn = document.getElementById('addMaterialBtn');
const materialModal = document.getElementById('materialModal');
const closeMaterialModalBtn = document.querySelector('.close');
const materialForm = document.getElementById('materialForm');
const materialsBody = document.getElementById('materialsBody');
const saveSettingsBtn = document.getElementById('saveSettingsBtn');
const resetSettingsBtn = document.getElementById('resetSettingsBtn');
const defaultCompanyNameInput = document.getElementById('defaultCompanyName');
const minDiscountRateInput = document.getElementById('minDiscountRate');
const totalAmount = document.getElementById('totalAmount');
const quotationDate = document.getElementById('quotationDate');
const quotationBody = document.getElementById('quotationBody');
const pageTitle = document.getElementById('pageTitle');
const pageHeader = document.getElementById('pageHeader');

// 初始化
document.addEventListener('DOMContentLoaded', function() {
    // 设置默认日期
    quotationDate.value = new Date().toISOString().split('T')[0];
    
    // 加载材料数据
    loadMaterials();
    
    // 加载系统设置
    loadSystemSettings();
    
    // 添加默认材料（如果没有数据）
    if (materials.length === 0) {
        addDefaultMaterials();
    }
    
    // 绑定事件
    bindEvents();
    
    // 添加一行默认报价项
    addQuotationRow();

    // 初始化拖拽排序
    initSortable();

    // 检查更新
    checkUpdate();
});

// 初始化拖拽排序
function initSortable() {
    const materialsTbody = document.getElementById('materialsTable').querySelector('tbody');
    if (!materialsTbody) return;
    new Sortable(materialsTbody, {
        handle: '.drag-handle',
        animation: 150,
        onEnd: function (evt) {
            const oldIndex = evt.oldIndex;
            const newIndex = evt.newIndex;

            if (oldIndex !== newIndex) {
                // 更新 materials 数组
                const [movedItem] = materials.splice(oldIndex, 1);
                materials.splice(newIndex, 0, movedItem);

                // 保存新顺序
                saveMaterials();
                // 重新加载以更新UI和事件绑定
                loadMaterials();
            }
        }
    });
}

// 检查更新
async function checkUpdate() {
    try {
        // 获取本地版本信息
        const localVersionResponse = await fetch('version.json');
        const localVersionData = await localVersionResponse.json();
        const localVersion = localVersionData.version;

        // 获取远程版本信息
        const remoteVersionResponse = await fetch(localVersionData.updateUrl);
        const remoteVersionData = await remoteVersionResponse.json();
        const remoteVersion = remoteVersionData.version;

        // 比较版本
        if (compareVersions(remoteVersion, localVersion) > 0) {
            // 发现新版本，提示用户更新
            if (confirm(`发现新版本 ${remoteVersion}，是否立即下载更新？`)) {
                window.open(remoteVersionData.downloadUrl, '_blank');
            }
        }
    } catch (error) {
        console.error('检查更新失败:', error);
    }
}

// 比较版本号 (例如 '1.3.1' > '1.3.0')
function compareVersions(v1, v2) {
    const parts1 = v1.split('.').map(Number);
    const parts2 = v2.split('.').map(Number);
    const len = Math.max(parts1.length, parts2.length);

    for (let i = 0; i < len; i++) {
        const p1 = parts1[i] || 0;
        const p2 = parts2[i] || 0;
        if (p1 > p2) return 1;
        if (p1 < p2) return -1;
    }
    return 0;
}

// 绑定事件
function bindEvents() {
    // 标签页切换
    quotationTab.addEventListener('click', () => switchTab('quotation'));
    settingsTab.addEventListener('click', () => switchTab('settings'));
    
    // 报价单操作
    if (addRowBtn) addRowBtn.addEventListener('click', addQuotationRow);
    if (calculateBtn) calculateBtn.addEventListener('click', calculateTotal);
    if (discountBtn) discountBtn.addEventListener('click', applyDiscount);
    if (restorePriceBtn) restorePriceBtn.addEventListener('click', restoreOriginalPrices);
    if (exportBtn) exportBtn.addEventListener('click', exportQuotation);
    if (clearBtn) clearBtn.addEventListener('click', clearQuotation);
    
    // 材料管理
    if (addMaterialBtn) addMaterialBtn.addEventListener('click', () => openMaterialModal());
    
    // 模态框
    if (closeMaterialModalBtn) closeMaterialModalBtn.addEventListener('click', hideMaterialModal);
    const cancelBtn = document.getElementById('cancelBtn');
    const saveMaterialBtn = document.getElementById('saveMaterialBtn');
    if (cancelBtn) cancelBtn.addEventListener('click', hideMaterialModal);
    if (saveMaterialBtn) saveMaterialBtn.addEventListener('click', saveMaterial);
    
    // 系统设置相关事件
    if (saveSettingsBtn) saveSettingsBtn.addEventListener('click', saveSystemSettings);
    if (resetSettingsBtn) resetSettingsBtn.addEventListener('click', resetSystemSettings);
    
    // 点击模态框外部关闭
    window.addEventListener('click', function(event) {
        if (materialModal && event.target === materialModal) {
            hideMaterialModal();
        }
    });
    

}

// 切换标签页
function switchTab(tab) {
    if (tab === 'quotation') {
        quotationTab.classList.add('active');
        settingsTab.classList.remove('active');
        quotationPage.classList.add('active');
        settingsPage.classList.remove('active');
    } else {
        settingsTab.classList.add('active');
        quotationTab.classList.remove('active');
        settingsPage.classList.add('active');
        quotationPage.classList.remove('active');
    }
}

// 添加默认材料
function addDefaultMaterials() {
    const defaultMaterials = [
        // 广告类型材料
        { type: '广告', name: 'PVC板', spec: '3mm厚', cost: 30, unit: '平方米', note: '白色PVC板材' },
        { type: '广告', name: '亚克力板', spec: '5mm厚', cost: 54, unit: '平方米', note: '透明亚克力' },
        { type: '广告', name: 'KT板', spec: '5mm厚', cost: 10, unit: '平方米', note: '白色KT板' },
        { type: '广告', name: '不锈钢字', spec: '拉丝面', cost: 144, unit: '平方米', note: '304不锈钢' },
        { type: '广告', name: 'LED灯带', spec: '5050', cost: 18, unit: '米', note: '白光LED' },
        { type: '广告', name: '铝塑板', spec: '4mm厚', cost: 42, unit: '平方米', note: '银色铝塑板' },
        // 印刷类型材料
        { type: '印刷', name: '名片印刷', spec: '300g铜版纸', cost: 0.5, unit: '张', note: '双面彩印' },
        { type: '印刷', name: '宣传单印刷', spec: '157g铜版纸', cost: 0.3, unit: '张', note: '单面彩印' },
        { type: '印刷', name: '海报印刷', spec: '200g相纸', cost: 2.5, unit: '张', note: 'A3尺寸' },
        { type: '印刷', name: '画册印刷', spec: '250g铜版纸', cost: 8, unit: '本', note: '16页装订' }
    ];
    
    materials = defaultMaterials;
    saveMaterials();
    loadMaterials();
}

// 加载材料列表
function loadMaterials() {
    materialsBody.innerHTML = '';
    materials.forEach((material, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${material.type || '广告'}</td>
            <td>${material.name}</td>
            <td>${material.spec}</td>
            <td>¥${material.cost.toFixed(2)}</td>
            <td>${material.unit}</td>
            <td>${material.note}</td>
            <td>
                <button class="edit-btn" onclick="editMaterial(${index})">编辑</button>
                <button class="delete-btn" onclick="deleteMaterial(${index})">删除</button>
            </td>
            <td class="drag-handle">☰</td>
        `;
        materialsBody.appendChild(row);
    });
}

// 保存材料到本地存储
function saveMaterials() {
    localStorage.setItem('materials', JSON.stringify(materials));
}

// 打开材料模态框
function openMaterialModal(material = null) {
    currentEditingMaterial = material;
    
    if (material) {
        document.getElementById('materialType').value = material.type || '广告';
        document.getElementById('materialName').value = material.name;
        document.getElementById('materialSpec').value = material.spec;
        document.getElementById('materialCost').value = material.cost;
        document.getElementById('materialUnit').value = material.unit;
        document.getElementById('materialNote').value = material.note;
    } else {
        materialForm.reset();
    }
    
    materialModal.style.display = 'block';
}

// 关闭材料模态框
function hideMaterialModal() {
    materialModal.style.display = 'none';
    currentEditingMaterial = null;
}

// 保存材料
function saveMaterial() {
    const type = document.getElementById('materialType').value;
    const name = document.getElementById('materialName').value.trim();
    const spec = document.getElementById('materialSpec').value.trim();
    const cost = parseFloat(document.getElementById('materialCost').value);
    const unit = document.getElementById('materialUnit').value;
    const note = document.getElementById('materialNote').value.trim();
    
    if (!name || isNaN(cost) || cost < 0) {
        alert('请填写完整的材料信息，单价必须为有效数字！');
        return;
    }
    
    const materialData = { type, name, spec, cost, unit, note };
    
    if (currentEditingMaterial !== null) {
        // 编辑现有材料
        const index = materials.findIndex(m => m === currentEditingMaterial);
        materials[index] = materialData;
    } else {
        // 添加新材料
        materials.push(materialData);
    }
    
    saveMaterials();
    loadMaterials();
    hideMaterialModal();
}

// 编辑材料
function editMaterial(index) {
    openMaterialModal(materials[index]);
}

// 删除材料
function deleteMaterial(index) {
    if (confirm('确定要删除这个材料吗？')) {
        materials.splice(index, 1);
        saveMaterials();
        loadMaterials();
    }
}

// 添加报价行
function addQuotationRow() {
    const row = document.createElement('tr');
    const rowIndex = quotationItems.length;
    
    row.innerHTML = `
        <td>${rowIndex + 1}</td>
        <td>
            <select onchange="updateMaterialInfo(${rowIndex})" data-field="material">
                <option value="">请选择材料</option>
                ${materials.map(m => `<option value="${m.name}" data-cost="${m.cost}" data-unit="${m.unit}">${m.name} (${m.spec})</option>`).join('')}
            </select>
        </td>
        <td><input type="number" min="0" step="0.01" placeholder="长度" data-field="length" oninput="calculateRowTotal(${rowIndex})"></td>
        <td><input type="number" min="0" step="0.01" placeholder="宽度" data-field="width" oninput="calculateRowTotal(${rowIndex})"></td>
        <td><input type="number" min="0" step="0.01" placeholder="数量" data-field="quantity" oninput="calculateRowTotal(${rowIndex})"></td>
        <td class="unit-cell">-</td>
        <td><input type="number" min="0" step="0.01" placeholder="单价" data-field="price" oninput="calculateRowTotal(${rowIndex})"></td>
        <td class="subtotal">0.00</td>
        <td><button class="delete-btn" onclick="deleteQuotationRow(${rowIndex})">删除</button></td>
    `;
    
    quotationBody.appendChild(row);
    quotationItems.push({
        material: '',
        length: 0,
        width: 0,
        quantity: 0,
        price: 0,
        subtotal: 0
    });
    
    // 绑定输入事件
    const inputs = row.querySelectorAll('input');
    inputs.forEach(input => {
        input.addEventListener('input', function() {
            const field = this.getAttribute('data-field');
            quotationItems[rowIndex][field] = this.value;
        });
    });
}

// 更新材料信息
function updateMaterialInfo(rowIndex) {
    const row = quotationBody.children[rowIndex];
    const select = row.querySelector('select');
    const selectedOption = select.options[select.selectedIndex];
    const unitCell = row.querySelector('.unit-cell');
    const priceInput = row.querySelector('input[data-field="price"]');
    
    if (selectedOption.value) {
        const cost = parseFloat(selectedOption.getAttribute('data-cost'));
        const unit = selectedOption.getAttribute('data-unit');
        
        unitCell.textContent = unit;
        priceInput.value = cost.toFixed(2);
        
        quotationItems[rowIndex].material = selectedOption.value;
        quotationItems[rowIndex].price = cost;
        
        calculateRowTotal(rowIndex);
    } else {
        unitCell.textContent = '-';
        priceInput.value = '';
        quotationItems[rowIndex].material = '';
        quotationItems[rowIndex].price = 0;
    }
}

// 计算行小计
function calculateRowTotal(rowIndex) {
    const row = quotationBody.children[rowIndex];
    const materialName = row.querySelector('select[data-field="material"]').value;
    const length = parseFloat(row.querySelector('input[data-field="length"]').value) || 0;
    const width = parseFloat(row.querySelector('input[data-field="width"]').value) || 0;
    const quantity = parseFloat(row.querySelector('input[data-field="quantity"]').value) || 0;
    const price = parseFloat(row.querySelector('input[data-field="price"]').value) || 0;
    
    // 获取材料类型
    const material = materials.find(m => m.name === materialName);
    const materialType = material ? material.type : '广告';
    
    let subtotal = 0;
    
    if (materialType === '印刷') {
        // 印刷类型：单价 × 数量
        subtotal = quantity * price;
    } else {
        // 广告类型：单价 × 数量 × 面积（长×宽）
        // 计算面积（平方米）
        let area = length * width;
        
        // 面积修正规则
        if (area < 1) {
            // 不足1平方按1平方计算
            area = 1;
        } else if (area > 1) {
            // 大于1平方时进行小数修正
            const integerPart = Math.floor(area);
            const decimalPart = area - integerPart;
            
            if (decimalPart > 0 && decimalPart <= 0.3) {
                // 小数部分0-0.3，修正为0.5
                area = integerPart + 0.5;
            } else if (decimalPart > 0.3 && decimalPart < 1) {
                // 小数部分大于0.3，进位到下一个整数
                area = integerPart + 1;
            }
        }
        
        // 小计 = 数量 × 单价 × 修正后的平方米
        subtotal = quantity * price * area;
    }
    
    row.querySelector('.subtotal').textContent = subtotal.toFixed(2);
    quotationItems[rowIndex].subtotal = subtotal;
    
    calculateTotal();
}

// 删除报价行
function deleteQuotationRow(rowIndex) {
    if (quotationItems.length <= 1) {
        alert('至少需要保留一行！');
        return;
    }
    
    quotationBody.children[rowIndex].remove();
    quotationItems.splice(rowIndex, 1);
    
    // 重新编号
    Array.from(quotationBody.children).forEach((row, index) => {
        row.children[0].textContent = index + 1;
        // 更新事件处理器
        const deleteBtn = row.querySelector('.delete-btn');
        deleteBtn.setAttribute('onclick', `deleteQuotationRow(${index})`);
        
        const select = row.querySelector('select');
        select.setAttribute('onchange', `updateMaterialInfo(${index})`);
        
        const inputs = row.querySelectorAll('input[data-field="length"], input[data-field="width"], input[data-field="quantity"], input[data-field="price"]');
        inputs.forEach(input => {
            input.setAttribute('oninput', `calculateRowTotal(${index})`);
        });
    });
    
    calculateTotal();
}

// 计算总价
function calculateTotal() {
    const total = quotationItems.reduce((sum, item) => sum + (item.subtotal || 0), 0);
    totalAmount.textContent = total.toFixed(2);
}

// 清空报价单
function clearQuotation() {
    if (confirm('确定要清空所有报价项吗？')) {
        quotationBody.innerHTML = '';
        quotationItems = [];
        addQuotationRow();
        calculateTotal();
        
        // 清空项目信息，但保留默认公司名称
        document.getElementById('companyName').value = systemSettings.defaultCompanyName || '';
        document.getElementById('projectName').value = '';
        document.getElementById('customerName').value = '';
        document.getElementById('quotationDate').value = new Date().toISOString().split('T')[0];
    }
}

// 导出报价单
function exportQuotation() {
    const companyName = document.getElementById('companyName').value || '未填写公司';
    const projectName = document.getElementById('projectName').value || '未命名项目';
    const customerName = document.getElementById('customerName').value || '未填写';
    const quotationDate = document.getElementById('quotationDate').value || new Date().toISOString().split('T')[0];

    const total = totalAmount.textContent || '0.00';
    
    // 检查是否有报价项目
    if (quotationItems.length === 0 || quotationItems.every(item => !item.material)) {
        alert('请至少添加一个有效的报价项目！');
        return;
    }
    
    let html = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>报价单 - ${projectName}</title>
            <style>
                body { font-family: 'Microsoft YaHei', Arial, sans-serif; margin: 20px; line-height: 1.6; }
                .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #333; padding-bottom: 20px; }
                .header h1 { color: #2c3e50; margin-bottom: 10px; }
                .header .company { font-size: 18px; color: #666; font-weight: bold; }
                .info { margin-bottom: 20px; background-color: #f8f9fa; padding: 15px; border-radius: 5px; }
                .info-row { display: flex; justify-content: space-between; margin-bottom: 8px; }
                table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
                th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
                th { background-color: #f2f2f2; font-weight: bold; text-align: center; }
                td { text-align: center; }
                td:nth-child(2), td:nth-child(3) { text-align: left; }
                .total { font-weight: bold; background-color: #e9ecef; font-size: 16px; }
                .footer { margin-top: 30px; text-align: right; color: #666; position: relative; }
                .company-info { position: relative; color: #000; }
                .company-seal { position: absolute; right: 0; top: -10px; width: 180px; height: 180px; opacity: 0.8; z-index: 10; }
                .amount { color: #dc3545; font-weight: bold; }
                @media print { body { margin: 0; } .no-print { display: none; } }
            </style>
        </head>
        <body>
            <div class="header">
                <h1>广告制作报价单</h1>
                <div class="company">${companyName}</div>
            </div>
            <div class="info">
                <div class="info-row">
                    <span><strong>项目名称：</strong>${projectName}</span>
                    <span><strong>客户名称：</strong>${customerName}</span>
                </div>
                <div class="info-row">
                    <span><strong>报价日期：</strong>${quotationDate}</span>
                    <span></span>
                </div>
            </div>
            <table>
                <thead>
                    <tr>
                        <th width="8%">序号</th>
                        <th width="20%">材料名称</th>
                        <th width="10%">长度(米)</th>
                        <th width="10%">宽度(米)</th>
                        <th width="10%">数量</th>
                        <th width="10%">单位</th>
                        <th width="12%">单价(元)</th>
                        <th width="20%">小计(元)</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    // 只导出有效的报价项目
    let validItemCount = 0;
    quotationItems.forEach((item, index) => {
        const row = quotationBody.children[index];
        if (!row) return;
        
        const material = row.querySelector('select').value;
        if (!material) return; // 跳过没有选择材料的行
        
        validItemCount++;
        const length = row.querySelector('input[data-field="length"]').value || '-';
        const width = row.querySelector('input[data-field="width"]').value || '-';
        const quantity = row.querySelector('input[data-field="quantity"]').value || '0';
        const unit = row.querySelector('.unit-cell').textContent || '-';
        const price = parseFloat(row.querySelector('input[data-field="price"]').value || '0').toFixed(2);
        const subtotal = parseFloat(row.querySelector('.subtotal').textContent || '0').toFixed(2);
        
        html += `
            <tr>
                <td>${validItemCount}</td>
                <td>${material}</td>
                <td>${length}</td>
                <td>${width}</td>
                <td>${quantity}</td>
                <td>${unit}</td>
                <td>¥${price}</td>
                <td class="amount">¥${subtotal}</td>
            </tr>
        `;
    });
    
    html += `
                    <tr class="total">
                        <td colspan="7"><strong>合计金额</strong></td>
                        <td class="amount"><strong>¥${total}</strong></td>
                    </tr>
                </tbody>
            </table>
            <div class="footer">
                <div class="company-info">
                    <p>报价单位：${companyName}</p>
                    <p>报价日期：${new Date().toLocaleDateString()}</p>
                    <img src="images/seal.png" alt="公章" class="company-seal">
                </div>
                <p class="no-print">此报价单由广告报价软件生成</p>
            </div>
        </body>
        </html>
    `;
    
    // 创建新窗口并打印
    const printWindow = window.open('', '_blank');
    
    if (printWindow) {
        // 如果成功打开新窗口
        printWindow.document.write(html);
        printWindow.document.close();
        printWindow.focus();
        
        // 延迟打印，确保内容加载完成
        setTimeout(() => {
            printWindow.print();
        }, 500);
    } else {
        // 如果弹窗被阻止，使用下载方式
        const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `报价单-${projectName}-${new Date().toISOString().split('T')[0]}.html`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        alert('报价单已下载到本地，请打开文件查看或打印。');
    }
}

// 键盘快捷键
document.addEventListener('keydown', function(e) {
    // Ctrl + N: 添加新行
    if (e.ctrlKey && e.key === 'n') {
        e.preventDefault();
        addQuotationRow();
    }
    
    // Ctrl + S: 计算总价
    if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        calculateTotal();
    }
    
    // Ctrl + P: 导出报价单
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        exportQuotation();
    }
});

// 更新页面标题
function updatePageTitle() {
    const companyName = systemSettings.defaultCompanyName;
    const title = companyName ? `${companyName}报价单` : '报价单';
    
    if (pageTitle) pageTitle.textContent = title;
    if (pageHeader) pageHeader.textContent = title;
}

// 系统设置相关函数
function loadSystemSettings() {
    const saved = localStorage.getItem('systemSettings');
    if (saved) {
        systemSettings = JSON.parse(saved);
    }
    
    // 更新界面
    if (defaultCompanyNameInput) {
        defaultCompanyNameInput.value = systemSettings.defaultCompanyName;
    }
    if (minDiscountRateInput) {
        minDiscountRateInput.value = systemSettings.minDiscountRate || 0.8;
    }
    
    // 更新页面标题
    updatePageTitle();
    
    // 如果公司名称为空且有默认值，则填入默认值
    const companyNameInput = document.getElementById('companyName');
    if (!companyNameInput.value && systemSettings.defaultCompanyName) {
        companyNameInput.value = systemSettings.defaultCompanyName;
    }
}

function saveSystemSettings() {
    systemSettings.defaultCompanyName = defaultCompanyNameInput ? defaultCompanyNameInput.value : '';
    systemSettings.minDiscountRate = minDiscountRateInput ? (parseFloat(minDiscountRateInput.value) || 0.8) : 0.8;
    
    // 验证折扣率范围
    if (systemSettings.minDiscountRate < 0.1 || systemSettings.minDiscountRate > 1) {
        alert('保底折扣率必须在0.1到1之间！');
        return;
    }
    
    localStorage.setItem('systemSettings', JSON.stringify(systemSettings));
    
    // 更新页面标题
    updatePageTitle();
    
    alert('设置已保存！');
}

function resetSystemSettings() {
    if (confirm('确定要恢复默认设置吗？')) {
        systemSettings = {
            defaultCompanyName: '',
            minDiscountRate: 0.8
        };
        
        if (defaultCompanyNameInput) {
            defaultCompanyNameInput.value = '';
        }
        if (minDiscountRateInput) {
            minDiscountRateInput.value = 0.8;
        }
        
        localStorage.setItem('systemSettings', JSON.stringify(systemSettings));
        
        // 更新页面标题
        updatePageTitle();
        
        alert('设置已恢复默认值！');
    }
}

// 自动保存功能
setInterval(() => {
    const quotationData = {
        items: quotationItems,
        companyName: document.getElementById('companyName').value,
        projectName: document.getElementById('projectName').value,
        customerName: document.getElementById('customerName').value,
        quotationDate: document.getElementById('quotationDate').value,
        profitRate: document.getElementById('profitRate').value
    };
    localStorage.setItem('currentQuotation', JSON.stringify(quotationData));
}, 30000); // 每30秒自动保存

// 页面加载时恢复数据
window.addEventListener('load', function() {
    const savedQuotation = localStorage.getItem('currentQuotation');
    if (savedQuotation) {
        try {
            const data = JSON.parse(savedQuotation);
            if (data.companyName) document.getElementById('companyName').value = data.companyName;
            if (data.projectName) document.getElementById('projectName').value = data.projectName;
            if (data.customerName) document.getElementById('customerName').value = data.customerName;
            if (data.quotationDate) document.getElementById('quotationDate').value = data.quotationDate;
            if (data.profitRate) document.getElementById('profitRate').value = data.profitRate;
        } catch (e) {
            console.log('恢复数据失败:', e);
        }
    }
});

// 一键打折功能
function applyDiscount() {
    const discountInput = prompt('请输入折扣率（如0.8表示8折）:', '0.9');
    if (!discountInput) return;
    
    const discountRate = parseFloat(discountInput);
    if (isNaN(discountRate) || discountRate <= 0 || discountRate > 1) {
        alert('请输入有效的折扣率（0-1之间的数字）！');
        return;
    }
    
    // 检查是否低于保底折扣
    if (discountRate < systemSettings.minDiscountRate) {
        alert(`折扣率不能低于保底折扣${(systemSettings.minDiscountRate * 100).toFixed(0)}%！`);
        return;
    }
    
    // 保存原始价格（如果还没有保存）
    if (originalPrices.length === 0) {
        quotationItems.forEach((item, index) => {
            const row = quotationBody.children[index];
            const priceInput = row.querySelector('input[data-field="price"]');
            originalPrices[index] = parseFloat(priceInput.value) || 0;
        });
    }
    
    // 应用折扣
    quotationItems.forEach((item, index) => {
        const row = quotationBody.children[index];
        const priceInput = row.querySelector('input[data-field="price"]');
        const originalPrice = originalPrices[index] || parseFloat(priceInput.value) || 0;
        const discountedPrice = originalPrice * discountRate;
        
        priceInput.value = discountedPrice.toFixed(2);
        quotationItems[index].price = discountedPrice;
        
        // 重新计算小计
        calculateRowTotal(index);
    });
    
    calculateTotal();
    alert(`已应用${(discountRate * 100).toFixed(0)}%折扣！`);
}

// 恢复原价功能
function restoreOriginalPrices() {
    if (originalPrices.length === 0) {
        alert('没有可恢复的原价！');
        return;
    }
    
    if (!confirm('确定要恢复所有材料的原价吗？')) {
        return;
    }
    
    // 恢复原价
    quotationItems.forEach((item, index) => {
        if (originalPrices[index] !== undefined) {
            const row = quotationBody.children[index];
            const priceInput = row.querySelector('input[data-field="price"]');
            
            priceInput.value = originalPrices[index].toFixed(2);
            quotationItems[index].price = originalPrices[index];
            
            // 重新计算小计
            calculateRowTotal(index);
        }
    });
    
    // 清空原价记录
    originalPrices = [];
    
    calculateTotal();
    alert('已恢复所有材料的原价！');
}